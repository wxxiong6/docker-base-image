##Yaf Codes Generator

###Usage
```
php yaf_cg -d Sample
```

will generator folder "Sample" under output:
```
$ ls ./Sample/
application/  conf/  index.php  readme.txt
```
```
php yaf_cg -d Sample -n
will generate a namespace example
```
